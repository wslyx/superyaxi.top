<?php
/**
 * Created by PhpStorm.
 * User: sssl
 * Date: 2018/9/7
 * Time: 3:54 PM
 */
return array(
    "xhprofDir" => "/Users/sssl/akaxincom/xprof-logs/",
);